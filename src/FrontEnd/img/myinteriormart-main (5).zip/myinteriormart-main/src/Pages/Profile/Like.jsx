import React from 'react'

const Like = () => {
  return (
    <div>Like</div>
  )
}

export default Like