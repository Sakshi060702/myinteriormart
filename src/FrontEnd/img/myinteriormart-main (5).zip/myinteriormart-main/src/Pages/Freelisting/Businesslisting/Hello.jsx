import React from 'react'

const Hello = () => {
  return (
    <div>Hello</div>
  )
}

export default Hello