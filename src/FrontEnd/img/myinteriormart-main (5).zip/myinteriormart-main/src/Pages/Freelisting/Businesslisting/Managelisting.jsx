import React from "react";
import { Link } from "react-router-dom";

function Managelisting(){
    return(
        <>
        <div>
            <Link to="Hello"  >Specialisations</Link>
        </div>
        </>
    )
}
export default Managelisting;