import React from "react";
function Trial(){
    return(
        <div>Hello world</div>
    )
}
export default Trial