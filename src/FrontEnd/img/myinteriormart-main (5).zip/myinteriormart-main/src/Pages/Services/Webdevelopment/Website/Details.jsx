import React from "react";

function Details(){
    return(
        <>
        <h1>Hello World</h1>
        </>
    )
}
export default Details;