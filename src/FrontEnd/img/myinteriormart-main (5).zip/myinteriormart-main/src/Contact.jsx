import React from "react";

function Contact(){
    return(
        <>
        <h1>Hello world</h1>
        </>
    )
}
export default Contact;